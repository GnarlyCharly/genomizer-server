#! /bin/bash
#c08esn
#Setup ssh tunnels to itchy
#parameter: CS-username
echo "!WARNING! This will kill all current connections from and to the server!"
echo "Are you sure you want to continue?(y/n):"
read answer
if [ $answer == "y" ]
then
        if [ ! -z $1 ] 
        then
                echo "Type in server user password to restart software and kill all current ssh tunnels"
                sudo service apache2 restart
                sudo service postgresql restart
                sudo killall ssh
                echo "Setting up ssh tunnels on username, provide your password:" $1
                ssh -g -R 8000:localhost:80 -f -N $1@scratchy.cs.umu.se
                ssh -g -R 2200:localhost:22 -f -N $1@scratchy.cs.umu.se
                ssh -g -R 7000:localhost:7000 -f -N $1@scratchy.cs.umu.se
                ssh -g -R 6000:localhost:6000 -f -N $1@scratchy.cs.umu.se
		ssh -g -R 7331:localhost:7331 -f -N $1@scratchy.cs.umu.se
        else
                echo "Usage: ./restartserver.sh [CS-username]"
        fi
fi
