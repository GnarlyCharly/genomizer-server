#!/bin/bash

PORT=22
USER=root
IP=mikro
SAVEPATH=/var/
READPATH=/var/www
rsync --ignore-existing --progress --delete --update -avze 'ssh -p '$PORT $READPATH $USER@$IP:$SAVEPATH
