#! /bin/bash
DATE=$(date -I)
DBUSER=postgres
DBNAME=genomizer
DBPORT=6000
SAVEFILE=SqlBackup-$DATE.sql
pg_dump -w -U $DBUSER -h localhost -p $DBPORT $DBNAME > tmp
echo pvt | sudo -S cp tmp /var/www/sqlbackup/$SAVEFILE 